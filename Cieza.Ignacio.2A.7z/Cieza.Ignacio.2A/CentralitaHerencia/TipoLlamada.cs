﻿public enum TipoLlamada {
    Local,
    Provincial,
    Todas
}