using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Ejercicio_02
{
    class Program
    {
        static void Main(string[] args)
        {
            Sello.mensaje = /*"";*/"Hola";

            Console.Write(Sello.imprimir());
            

            //Sello.Borrar();
            Sello.color = ConsoleColor.Blue;
            Sello.ImprimirEnColor();
            Console.Write(Sello.imprimir());

            //Console.WriteLine(Sello.Imprimir());

            Console.Read();
        }
    }
}
