﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Local : Llamada
    {
        #region Atributos

        protected float _costo;

        #endregion
        #region Propiedades

        public float CostoLlamada
        {
            get
            {
                return this.CalcularCosto();
            }
        }

        #endregion
        #region Constructores

        public Local(Llamada llamada, float costo) 
            :this(llamada.NroOrigen, llamada.Duracion, llamada.NroDestino, costo)
        {

        }

        public Local(string origen, float duracion, string destino, float costo) 
            :base(duracion, destino, origen)
        {
            this._costo = costo;
        }
        #endregion
        #region Metodos

        private float CalcularCosto()
        {
            float costoLlamada = 0;

            costoLlamada = this._costo * base.Duracion;

            return costoLlamada;
        }

        public new string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.Mostrar());
            sb.AppendFormat("El costo de la llamada es: {0}", this.CalcularCosto());

            return sb.ToString();
        }

        #endregion

    }
}
