﻿public enum Emarcas
{
    Honda, Ford, Zanella, Scania, Iveco, Fiat
}