public enum EtipoTinta
{
  Comon,
  China,
  ConBrillo
  
}

