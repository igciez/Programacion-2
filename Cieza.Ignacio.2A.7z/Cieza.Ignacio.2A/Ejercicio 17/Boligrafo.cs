﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_17
{
    class Boligrafo
    {
        #region Atributos
        const short cantidadTintaMaxima = 100;
        private ConsoleColor _color;
        private short _tinta;
        #endregion
        
        #region Constructor
        public Boligrafo(ConsoleColor color, short tinta)
        {
            this._color = color;
            this._tinta = tinta;
        }
        #endregion
       
        #region Metodos
        public ConsoleColor GetColor()
        {
            return this._color;
        }
        public short GetTinta()
        {
            return this._tinta;
        }
        public bool Pintar(int gasto, out string dibujo)
        {
            int resultado;
            bool retorno = false;

            resultado = this._tinta - gasto;
            dibujo = "";

            if (resultado>0)
            {
                this._tinta = (short)resultado;              
                
                for (int i = 0; i < gasto; i++)
                {
                    dibujo += "*";
                }

                Console.ForegroundColor = this._color;             

                retorno = true;
            }        

            return retorno;
        }
        public void Recargar()
        {
            SetTinta(100);
            //this.SetTinta(100);
        }
        private void SetTinta(short tinta)
        {
            if(tinta > 0 && tinta <= 100)
            {
                this._tinta = tinta;
            }
            else
            {
                this._tinta = 0;
            }
        }
        #endregion
    }
}
