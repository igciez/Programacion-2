﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades.Clase06
{
    class Paleta
    {
        #region Atributos
        private Tempera[] _colores;
        private int _cantMaximaElementos;
        #endregion
        
        #region Constructor
        private Paleta():this(5) //otra manera de sobrecarga ahorrando espacio.
        {
            
        }
        private Paleta(int valorCantidad)
        {
            this._cantMaximaElementos = valorCantidad;
            this._colores = new Tempera[this._cantMaximaElementos];
        }
        #endregion

        #region Metodo

        private string Mostrar()
        {
            foreach(Tempera valorTempera in this._colores)
            {
                
            }

            return
        }


        #endregion
        #region Sobrecarga

        public static bool operator ==(Paleta valorPaleta, Tempera valorTemperatura)
        {

        }


        public static bool operator !=(Paleta valorPaleta, Tempera valorTemperatura)
        {

        }



    }
}
