﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno alumno1=new Alumno();
            Alumno alumno2 = new Alumno();
            Alumno alumno3 = new Alumno();

            alumno1.nombre = "Pedro";
            alumno1.apellido = "Perez";
            alumno1.legajo = 01;

            alumno2.nombre = "Juan";
            alumno2.apellido = "Rodriguez";
            alumno2.legajo = 02;

            alumno3.nombre = "Alfonzo";
            alumno3.apellido = "Torrado";
            alumno3.legajo = 03;

            alumno1.Estudiar(1, 2);
            alumno1.Mostrar();
            alumno2.Estudiar(4, 4);
            alumno2.Mostrar();

            Console.Read();

        }
    }
}
