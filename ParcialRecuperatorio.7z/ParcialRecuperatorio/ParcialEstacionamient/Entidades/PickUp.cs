﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class PickUp:Vehiculo
    {
        #region Atributos

        private string _modelo;
        static int _valorHora;

        #endregion
        #region Constructores 

        static PickUp()
        {
            PickUp._valorHora = 70;
        }

        public PickUp(string patente, string modelo):base(patente)
        {
            this._modelo = modelo;
        }

        public PickUp(string patente, string modelo, int valorHora)
            :this(patente,modelo)
        {
            PickUp._valorHora = valorHora;
        }
        #endregion
        #region Metodos

        public override string ConsultarDatos()
        {
            return String.Format("\nModelo:{0}\nValor Hora:{1}", this._modelo, PickUp._valorHora);
        }

        public override bool Equals(object obj)
        {
            return (obj is PickUp);
        }

        public override string ImprimirTicket()
        {
            StringBuilder sb = new StringBuilder();
            int costoEstadia = 0;

            costoEstadia = (DateTime.Now.Hour - base._ingreso.Hour) * PickUp._valorHora;

            sb.AppendLine(base.ImprimirTicket());
            sb.AppendLine(this.ConsultarDatos());
            sb.AppendFormat("\nCosto de la Estadia:{0}", costoEstadia);

            return sb.ToString();
        }


        #endregion
    }
}
