﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Arena
    {
        #region Atributos

        public int espacioDisponible;
        public string nombre;
        public List<RobotDeCombate> robotsDeCombate;
        public List<RobotSirviente> robotsSirvientes;

        #endregion
        #region Constructores

        private Arena()
        {
            this.robotsDeCombate = new List<RobotDeCombate>();
            this.robotsSirvientes = new List<RobotSirviente>();

        }

        public Arena(string nombre,int espacioDisponible)
            :this()
        {
            this.nombre = nombre;
            this.espacioDisponible = espacioDisponible;
        }

        #endregion
        #region Metodos
        /// <summary>
        /// Muestra el resultado de la pelea
        /// </summary>
        /// <param name="combatiente">robot contrincante</param>
        /// <returns>string, con el resultado</returns>
        public string Combate(RobotDeCombate combatiente)
        {
            StringBuilder sb = new StringBuilder();
            RobotDeCombate contrincante = new RobotDeCombate();

            if (!Object.Equals(combatiente,null) && combatiente.Energia > 0)
            {
                foreach(RobotDeCombate temporal in this.robotsDeCombate)
                {
                    if (temporal.Energia > 0)
                    {
                        contrincante = temporal;
                        break;                       
                        
                    }
                }
                
                sb.AppendLine(contrincante.ServirHumanidad());
                sb.AppendLine(combatiente.ServirHumanidad());

                if (!Object.Equals(contrincante, null))
                {
                    if (contrincante.CaballoDeFuerza > combatiente.CaballoDeFuerza)
                    {
                        sb.AppendFormat("\nGano: {0} ", contrincante.Codigo);
                    }
                    else if (contrincante.CaballoDeFuerza < combatiente.CaballoDeFuerza)
                    {
                        sb.AppendFormat("\nGano: {0} ", combatiente.Codigo);
                    }
                    else
                    {
                        sb.AppendLine("\nEmpate");
                    }
                }
                else
                {
                    sb.AppendLine("\nNo se encontro oponente");
                }
                
            }
            return sb.ToString();            
        }
        /// <summary>
        /// busca el robot que tenga energia
        /// </summary>
        /// <returns></returns>
        public string ServirEspectadores()
        {
            StringBuilder sb = new StringBuilder();
           
            foreach (RobotSirviente temporal in this.robotsSirvientes)
            {
                if (temporal.Energia > 0)
                {
                    sb.AppendLine(temporal.ServirHumanidad());
                    break;
                }
                else
                {
                    sb.AppendLine("");
                }

            }

            return sb.ToString();
        }
        /// <summary>
        /// Muestra la informacion de la arena
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("\nNombre arena:{0}", this.nombre);
            sb.AppendLine("\nRobot Combate");

            foreach (RobotDeCombate temporalCombate in this.robotsDeCombate)
            {
                sb.AppendLine(temporalCombate.ServirHumanidad());
            }

            sb.AppendLine("\nRobot Sirviente");
            foreach (RobotSirviente temporalSirviente in this.robotsSirvientes)
            {
                sb.AppendLine(temporalSirviente.ServirHumanidad());
            }

            return sb.ToString();
        }
        #endregion
        #region SobreCargas
        /// <summary>
        /// Muestra lista de robots tanto sirvientes como en combate
        /// </summary>
        /// <param name="arena"></param>
        public static implicit operator string(Arena arena)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("\nNombre arena:{0}", arena.nombre);
            sb.AppendLine("\nRobot Combate");

            foreach (RobotDeCombate temporalCombate in arena.robotsDeCombate)
            {
                sb.AppendLine(temporalCombate.ToString());
            }
            sb.AppendLine("\nRobot Sirviente");
            foreach (RobotSirviente temporalSirviente in arena.robotsSirvientes)
            {
                sb.AppendLine(temporalSirviente.ToString());
            }

            return sb.ToString();
        }

        public static bool operator ==(Arena arena, Robot robot)
        {
            bool retorno = false;

            foreach (Robot temporal in arena.robotsDeCombate)
            {
                if(temporal == robot)
                {
                    retorno= true;
                    break;
                }
            }
            foreach (Robot temporal in arena.robotsSirvientes)
            {
                if (temporal == robot)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }

        public static bool operator !=(Arena arena, Robot robot)
        {
            return !(arena == robot);
        }

        public static Arena operator +(Arena arena, Robot robot)
        {
            if (arena != robot)
            {
                if(robot is RobotDeCombate)
                {
                    arena.robotsDeCombate.Add((RobotDeCombate)robot);
                }
                else if(robot is RobotSirviente)
                {
                    arena.robotsSirvientes.Add((RobotSirviente)robot);
                }
            }

            return arena;
        }

        public static Arena operator -(Arena arena, Robot robot)
        {
            if (arena == robot)
            {
                if (robot is RobotDeCombate)
                {
                    arena.robotsDeCombate.Remove((RobotDeCombate)robot);
                }
                else if (robot is RobotSirviente)
                {
                    arena.robotsSirvientes.Remove((RobotSirviente)robot);
                }
            }

            return arena;

        }
        #endregion

    }
}
