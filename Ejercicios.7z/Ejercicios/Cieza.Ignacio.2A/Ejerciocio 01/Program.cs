﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejerciocio_01
{
    class Ejerciocio_01
    {
        static void Main(string[] args)
        {
            int numero;
            int i;
            int maximo = 0;
            int minimo = 0;
            float promedio;
            float acumulador = 0;

            Console.Title = "Ejercicio Nro 01";


            for (i = 0; i < 5; i++)
            {
                Console.WriteLine("Ingrese el numero {0}:", i + 1);
                numero = int.Parse(Console.ReadLine());
                acumulador += numero;


                if (i == 0)
                {
                    maximo = numero;
                    minimo = numero;
                }

                else if (numero > maximo)
                {
                    maximo = numero;
                }
                else if (numero < minimo)
                {
                    minimo = numero;
                }
            }

            promedio = acumulador / 5; //el acumulador se declara float porque si es int con int, no calcula decimal. entonces es necesario castear. ej. (float)5; para que al menos alguno sea decimal.

            Console.WriteLine("El maximo es: {0}", maximo);
            Console.WriteLine("El minimo es: {0}", minimo);
            Console.WriteLine("El promedio es: {0:0.00}", promedio);

            Console.Read();

        }
    }
}
       
