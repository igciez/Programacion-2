﻿public enum Divisiones
{
    A,
    B,
    C,
    D,
    E
}