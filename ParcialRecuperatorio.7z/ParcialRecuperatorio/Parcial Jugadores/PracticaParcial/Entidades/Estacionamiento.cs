﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Estacionamiento
    {
        #region Atributos

        private int _espacioDisponible;
        private string _nombre;
        private List<Vehiculo> _vehiculo;

        #endregion
        #region Constructores 

        private Estacionamiento()
        {
            this._vehiculo = new List<Vehiculo>();
        }

        public Estacionamiento(string nombre, int espacioDisponible):this()
        {
            this._nombre = nombre;
            this._espacioDisponible = espacioDisponible;

        }       

        #endregion       
        #region Sobrecargas

        public static explicit operator string(Estacionamiento e)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Espacio Disponible: {0}\nNombre {1}\n", e._espacioDisponible, e._nombre);

            if (!(object.Equals(e._vehiculo, null)))
            {
                foreach (Vehiculo vehiculo in e._vehiculo)
                {
                    sb.AppendLine(vehiculo.Patente);
                }
            }                

            return sb.ToString();
        }

        public static bool operator ==(Estacionamiento estacionamiento, Vehiculo vehiculo)
        {
            bool retorno = false;

            if(!(object.Equals(estacionamiento._vehiculo, null)))
            {
                foreach (Vehiculo temporal in estacionamiento._vehiculo)
                {
                    if (temporal == vehiculo)
                    {
                        retorno = true;
                        break;
                    }
                }
            }
            
            return retorno;
        }

        public static bool operator !=(Estacionamiento estacionamiento, Vehiculo vehiculo)
        {
            return !(estacionamiento == vehiculo);
        }

        public static Estacionamiento operator +(Estacionamiento estacionamiento,Vehiculo vehiculo)
        {           
            if (estacionamiento != vehiculo && !(Object.Equals(vehiculo.Patente, null)) && !(object.Equals(estacionamiento._vehiculo, null)) && estacionamiento._espacioDisponible !=0)
            {
                estacionamiento._vehiculo.Add(vehiculo);
                estacionamiento._espacioDisponible -= 1;
            }            

            return estacionamiento;
        }

        public static string operator -(Estacionamiento estacionamiento, Vehiculo vehiculo)
        {
            if (estacionamiento == vehiculo)
            {
                estacionamiento._vehiculo.Remove(vehiculo);
                estacionamiento._espacioDisponible += 1;
                return vehiculo.ImprimirTicket();
            }
            else
            {
                return "El vehiculo no es parte del estacionamiento.";
            }
        }

        #endregion
    }
}
