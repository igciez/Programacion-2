﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloParcial
{
    class Lavadero
    {
        #region Atributos

        private List<Vehiculo> _vehiculos;
        private static float _precioAuto;
        private static float _precioCamion;
        private static float _precioMoto;
        private string _razonSocial;

        #endregion
        #region Constructores

        private Lavadero()
        {
            this._vehiculos = new List<Vehiculo>();
        }

        public Lavadero(string razonSocial) : this()
        {          
            
            this._razonSocial = razonSocial;
        }

        static Lavadero()
        {

            Random rnd = new Random();

            Lavadero._precioAuto = rnd.Next(150, 565);
            Lavadero._precioCamion = rnd.Next(150, 565);
            Lavadero._precioMoto = rnd.Next(150, 565);

        }

        #endregion
        #region Propiedades 

        public string LavaderoToString
        {
            get
            {                        
               return this._vehiculos.ToString() + this._razonSocial + Lavadero._precioAuto.ToString() + Lavadero._precioCamion.ToString() + Lavadero._precioMoto.ToString();
            }
        } 

        public string Vehiculos
        {
            get
            {
                return "";

            }
        }

        #endregion
        #region Metodos

       public double MostrarTotalFacturado()
       {
            double valorTemporal=0;

            foreach (Vehiculo temporalVehiculo in this._vehiculos)
            {
                if(temporalVehiculo.CantRuedas == 2)
                {
                    valorTemporal +=Lavadero._precioMoto;
                }
                else if (temporalVehiculo.CantRuedas == 4)
                {
                    valorTemporal += Lavadero._precioAuto;
                }
                else if(temporalVehiculo.CantRuedas > 4)
                {
                    valorTemporal += Lavadero._precioCamion;
                }
            }

            return valorTemporal;
       }
        public double MostrarTotalFacturado(EVehiculos valorVehiculos )
        {
            double valorTemporal = 0;   
                   
            
            return valorTemporal;
        }




        #endregion




    }
}
