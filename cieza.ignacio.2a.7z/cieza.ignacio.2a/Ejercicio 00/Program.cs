﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_00
{
    class Program
    {
        static void Main(string[] args)
        {
            string nombre;
            int edad;

            Console.WriteLine("Ingrese Nombre:");
            nombre= Console.ReadLine();
            Console.WriteLine(nombre);
            Console.WriteLine("Ingrese edad:");
            edad = int.Parse(Console.ReadLine());
            Console.WriteLine(edad);
            Console.ReadLine();


        }
    }
}
