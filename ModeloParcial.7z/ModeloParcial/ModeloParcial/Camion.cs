﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloParcial
{
    class Camion:Vehiculo
    {
        #region Atributos

        protected float _tara;

        #endregion
        #region Constructor

        public Camion(string patente, byte cantRuedas, Emarcas marca, float tara) : base(patente, cantRuedas, marca)
        {
            this._tara = tara;
        }
        public Camion(Vehiculo vehiculo, float tara) : this(vehiculo.Patente, vehiculo.CantRuedas, vehiculo.Marca, tara)
        {

        }

        #endregion
        #region Metodos

        protected override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("La tara del Camion es: {0}", this._tara);
            //sb.AppendLine(base.Mostrar());

            return sb.ToString();
        }

        public override string ToString()
        {
            return base.Mostrar();
        }

        #endregion
    }
}
