﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class PrestamoPesos:Prestamo
    {
        #region Atributos

        private float _porcentajeInteres;

        #endregion
        #region Propiedades

        #endregion
        #region Constructores

        #endregion
        #region Metodos

        #endregion
    }
}
