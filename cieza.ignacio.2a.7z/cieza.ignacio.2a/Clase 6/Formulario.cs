using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clase_6
{
  public partial class Formulario : Form
  {
    private Clase_05.Tinta _tinta;//atributos desde el nombre de los namespace de las otras clases.
    private Clase_05.Pluma _pluma;

    public Formulario()
    {     
      InitializeComponent();
    }

    private void Formulario_Load(object sender, EventArgs e)
    {

    }

    private void tintaToolStripMenuItem_Click(object sender, EventArgs e)
    {
      frmTinta frm = new frmTinta();
      frm.Show();
    }
  }
}
