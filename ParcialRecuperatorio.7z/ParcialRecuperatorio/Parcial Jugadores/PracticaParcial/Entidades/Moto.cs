﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Moto:Vehiculo
    {
        #region Atributos

        private int _cilindrada;
        private short _ruedas;
        static int _valorHora;

        #endregion
        #region Constructores

        static Moto()
        {
            Moto._valorHora= 30;
        }
        public Moto(string patente, int cilindrada)
            :this(patente,cilindrada,2)
        {

        }
        public Moto(string patente, int cilindrada,short ruedas)
            :base(patente)
        {
            this._cilindrada = cilindrada;
            this._ruedas = ruedas;
        }
        public Moto(string patente, int cilindrada, short ruedas,int valorHora)
            : this(patente,cilindrada,ruedas)
        {
            Moto._valorHora = valorHora;
        }

        #endregion
        #region Metodos

        public override string ConsultarDatos()
        {
            return string.Format("\nCilindrada {0}\nRuedas {1}\nValor Hora {2}", this._cilindrada, this._ruedas, Moto._valorHora);
        }

        public override string ImprimirTicket()
        {
            StringBuilder sb = new StringBuilder();
            int costoEstadia = 0;

            costoEstadia = (int)((DateTime.Now - base._ingreso).TotalHours) * (Moto._valorHora);

            sb.AppendLine(base.ImprimirTicket());
            //sb.AppendLine(this.ConsultarDatos());
            sb.AppendFormat("La hora de Egreso es: {0}", DateTime.Now);
            sb.AppendFormat("\nEl costo de la estadia es {0}", costoEstadia);

            return sb.ToString();
        }

        public override bool Equals(object obj)
        {
            return (obj is Moto);
        }
        #endregion

    }
}
