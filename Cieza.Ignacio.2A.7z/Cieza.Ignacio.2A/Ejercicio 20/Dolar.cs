﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_20
{
    class Dolar
    {
        #region Atributos
        private double _cantidad;
        private float _cotizRespectoDolar;
        #endregion

        #region Constructores
        private Dolar():this(1,1)
        {
            
        }
        public Dolar(double cantidad):this()
        {
            this._cantidad = cantidad;
            
        }
        public Dolar(double cantidad, float cotizacion)
        {
            this._cantidad = cantidad;
            this._cotizRespectoDolar = cotizacion;
        }
        #endregion
        #region Sobrecargas
        public static explicit operator Euro(Dolar d)
        {
            Dolar dolar;
           // d._cotizRespectoDolar =(float)d._cantidad / 1.3642;
            dolar= new Dolar(d._cantidad,d._cotizRespectoDolar);
            Euro euro = new Euro();
        
            //euro = dolar._cantidad * dolar._cotizRespectoDolar;
            return euro;

        }


        #endregion

        #region Metodos

        public float GetCotizacion()
        {
            return this._cotizRespectoDolar;
        }

        #endregion
    }
}
