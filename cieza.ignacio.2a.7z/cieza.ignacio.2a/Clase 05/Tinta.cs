using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_05
{
  class Tinta
  {
    private ConsoleColor _color;
    private EtipoTinta _tipo;

    public Tinta()
    {
      this._color =ConsoleColor.Blue;
      this._tipo = EtipoTinta.ConBrillo;
    }

    public Tinta(ConsoleColor valorColor):this()
    {
      this._color = valorColor;
    }
    public Tinta(ConsoleColor valorColor, EtipoTinta valorTipo) : this(valorColor)
    {
      this._tipo = valorTipo;
    }

    public static string Mostrar(Tinta valorTinta)
    {
        return valorTinta.Mostrar();
    }

    private string Mostrar()
    {
      return this._color +"--"+this._tipo;
    }

    #region Sobrecarga op

    public static bool operator == (Tinta op1 , Tinta op2)
    {
      bool valor= false;

      if( == op)

      return;
    }

    public static bool operator !=(Tinta op1, Tinta op2)
    {

      return !=(op1 == op2);
    }


    #endregion

  }
}
