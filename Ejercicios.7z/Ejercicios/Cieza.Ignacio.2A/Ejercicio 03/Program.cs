﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_03
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero=0;
            int j;
            int i;
            int acumulador = 0;

            Console.Write("Ingrese un numero: ");
            numero = int.Parse(Console.ReadLine());

            for (i = 2;i <= numero; i++)
            {
                acumulador = 0;
                for (j = 2; j <= numero; j++)
                {                 
                    if (i % j == 0)
                    {                        
                        acumulador++;
                    }  
                }
                if (acumulador == 1)
                {
                    Console.Write("{0}  ", i);
                }
            }
            if(acumulador == 0)
            {
                Console.WriteLine("No hay numeros primos.");
            }

            Console.Read();
        }
    }
}
