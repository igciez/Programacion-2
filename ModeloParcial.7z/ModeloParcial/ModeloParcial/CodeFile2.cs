﻿public enum EVehiculos
{
    Auto,
    Camion,
    Moto
}