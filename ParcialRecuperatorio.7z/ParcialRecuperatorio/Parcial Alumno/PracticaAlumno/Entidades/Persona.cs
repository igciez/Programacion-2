﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Persona
    {
        #region Atributos

        private string _apellido;
        private string _documento;
        private string _nombre;

        #endregion
        #region Propiedades

        public string Apellido
        {
            get
            {
                return this._apellido;
            }
        }

        public string Documento
        {
            get
            {
               return this._documento;
            }

            set
            {
                if(this.ValidarDocumentacion(value))
                {
                    this._documento = value;
                }
            }
        }

        public string Nombre
        {
            get
            {
                return this._nombre;
            }
        }

        #endregion
        #region Constructor

        public Persona(string nombre,string apellido, string documento)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this.Documento = documento;
        }

        #endregion
        #region Metodos

        public abstract bool ValidarDocumentacion(string doc);

        public virtual string ExponerDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("\nNombre:{0}", this._nombre);
            sb.AppendFormat("\nApellido:{0}", this._apellido);
            sb.AppendFormat("\nDocumento:{0}", this._documento);

            return sb.ToString();
        }

        #endregion
    }
}
