﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Entidades
{
    public class Alumno:Persona
    {
        #region Atributos

        private short _anio;
        private Divisiones _division;

        #endregion
        #region Propiedades

        public string AnioDivision
        {
            get
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendFormat("{0}-o{1}", this._anio, this._division);

                return sb.ToString();
            }
        }


        #endregion
        #region Constructor

        public Alumno(string nombre,string apellido,string documento, short anio,Divisiones division)
            :base(nombre,apellido,documento)
        {
            this._anio = anio;
            this._division = division;
        }

        #endregion
        #region Metodos

        public override bool ValidarDocumentacion(string doc)
        {
            bool retorno = false;
            int posicion = 1;

            foreach(char a in doc)
            {                
                if (a >='0' && a<='9' && posicion == 1)
                {
                    posicion++;
                }
                else if(a >= '0' && a <= '9'  && posicion == 2)
                {
                    posicion++;
                }
                else if (a == '-' && posicion == 3)
                {
                    posicion++;
                }
                else if (a >= '0' && a <= '9' && posicion == 4)
                {
                    posicion++;
                }
                else if (a >= '0' && a <= '9' && posicion == 5)
                {
                    posicion++;
                }
                else if (a >= '0' && a <= '9' && posicion == 6)
                {
                    posicion++;
                }
                else if (a >= '0' && a <= '9' && posicion == 7)
                {
                    posicion++;
                }
                else if (a == '-' && posicion == 8)
                {
                    posicion++;
                }
                else if (a >= '0' && a <= '9' && posicion == 9)
                {
                    retorno = true;
                }
                else
                {
                    break;
                }
            }                    
 
            return retorno;
        }

        public override string ExponerDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.ExponerDatos());
            sb.AppendFormat("\nAnio: {0}", this._anio);
            sb.AppendFormat("\nDivision:{0}", this._division);

            return sb.ToString();
        }

        #endregion
    }
}
