﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_17
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio 17";
            Console.ForegroundColor = ConsoleColor.DarkGray;

            Boligrafo boligrafo1 = new Boligrafo(ConsoleColor.Blue,100);
            Boligrafo boligrafo2 = new Boligrafo(ConsoleColor.Red, 50);
            string dibujo = "";
            
            boligrafo2.Recargar();            
            Console.WriteLine("La tinta del boligrafo 2 es:{0}",boligrafo2.GetTinta());

            //Console.WriteLine("El color de la tinta del boligrafo 1 es:{0}", boligrafo1.GetColor);
            if(boligrafo1.Pintar(20, out dibujo))
            {
                Console.WriteLine("El gasto es: {0}", dibujo);
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.WriteLine("La tinta del boligrafo 1 es:{0}", boligrafo1.GetTinta());
            }
            else
            {
                Console.WriteLine("Recargue la tinta.");
            }

            if (boligrafo2.Pintar(100, out dibujo))
            {
                Console.WriteLine("El gasto es: {0}", dibujo);
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.WriteLine("La tinta del boligrafo 2 es:{0}", boligrafo2.GetTinta());
            }
            else
            {
                Console.WriteLine("Recargue la tinta del boligrafo 2, para poder pintar.");
            }

            Console.ReadLine();
            


        }
    }
}
