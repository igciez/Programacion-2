using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Entidades
{
    class Sello
    {
        public static String mensaje; //atributo
        public static ConsoleColor color; //atributo

        public static String Imprimir() //metodo 
        {
          /*if(Sello.TryParse(Sello.mensaje,out string cadena))
          {
            Sello.mensaje = cadena;
          }*/
          return ArmarFormatoMensaje();//Sello.mensaje;
        }
        public static void Borrar()
        {
            Sello.mensaje = "";
        }
        public static void ImprimirEnColor()
        {
            Console.ForegroundColor = Sello.color;
            Console.Write(Sello.Imprimir());
            Console.ForegroundColor= ConsoleColor.White;
        }
        private static string ArmarFormatoMensaje()
        {
          int asteriscos;
          int i;
          string a="";

          if (Sello.TryParse(Sello.mensaje, out string cadena))
          {

            asteriscos = cadena.Length;

            for (i = 0; i < asteriscos + 2; i++)
            {
              a += "*";
            }

            a += "\n*" + Sello.mensaje + "*\n";

            for (i = 0; i < asteriscos + 2; i++)
            {
              a += "*";
            }
            a += "\n";
          }
          else
          {
            a = "No hay mensaje para mostrar.\n";
          }
         return a; 
        }

        private static bool TryParse(string mensaje,out string salida)//out es un parametro de salida, se puede volver a usar dentro del metodo.
        {
          int longitud;
          salida = "";
          bool correcto;

          longitud = Sello.mensaje.Length;

          if(longitud > 0)
          {
            salida = mensaje;//asocio el mensaje a lo que va a salir, por lo que va a salir el out junto con el return.
            correcto = true;
            
          }
          else
          {
          correcto= false;
          salida = "No hay mensaje para mostrar.";
          }

           return correcto;
          
        }
        




    }
}
