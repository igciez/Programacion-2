﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
   public abstract class Robot
    {
        #region Atributos

        protected static int _capacidadEnergia;
        private static int _contador;
        private int _codigo;
        protected int _energia;
        protected string _origen;

        #endregion
        #region Propiedades
        
        public static int CapacidadEnergia
        {
            get
            {
                return Robot._capacidadEnergia;
            }
        }

        public int Codigo
        {
            get
            {
                return this._codigo;
            }
        }

        public int Energia
        {
            get
            {
                return this._energia;
            }
        }

        #endregion
        #region Constructores

        static Robot()
        {
            Robot._capacidadEnergia = 50;
            Robot._contador = 0;
        }

        protected Robot()
        {
            this._origen = "Coreano";
            this._energia = 10;
            this._codigo = Robot._contador++;
        }

        public Robot(int energia,string origen):this()
        {
            this._energia = energia;
            this._origen = origen;
        }



        #endregion
        #region Metodos
        
        /// <summary>
        /// Valida si la enrgia es mayor a 0 y menor a la capacidadEnergia
        /// </summary>
        /// <param name="energia"> Valor a validar</param>
        /// <returns>bool</returns>
        public virtual bool CargarEnergia(int energia)
        {
            bool retorno = false;

            if (this._energia > 0 && this._energia < Robot.CapacidadEnergia)
            {
                this._energia = energia;
                retorno = true;
            }

            return retorno;
        }

        public abstract string ServirHumanidad();
        #endregion
        #region SobreCargas
        /// <summary>
        /// Compara dos Robot por atributo codigo
        /// </summary>
        /// <param name="robot1">primer valor a comparar </param>
        /// <param name="robot2">segundo valor a comparar</param>
        /// <returns>bool</returns>
        public static bool operator ==(Robot robot1, Robot robot2)
        {
           return (robot1._codigo == robot2._codigo) ;
        }

        public static bool operator !=(Robot robot1, Robot robot2)
        {
            return !(robot1 == robot2);
        }
        /// <summary>
        /// Muestra la informacion del Robot
        /// </summary>
        /// <returns>string</returns>
        public override string ToString()
        {
            return String.Format("\nCodigo:{0}\nCapacidad Energia:{1}\nContador:{2}\nOrigen:{3}", this.Codigo, this.Energia, Robot._contador, this._origen);
        }

        #endregion
    }
}
