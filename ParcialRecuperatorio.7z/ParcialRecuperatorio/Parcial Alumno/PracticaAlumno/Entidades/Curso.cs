﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Curso
    {
        #region Atributos

        private List<Alumno> _alumnos;
        private short _anio;
        private Divisiones _division;
        private Profesor _profesor;

        #endregion
        #region Propiedades

        public string AnioDivision
        {
            get
            {
                StringBuilder sb = new StringBuilder();

                sb.AppendFormat("{0}-o{1}", this._anio, this._division);

                return sb.ToString();
            }
        }

        #endregion
        #region Constructores

        private Curso()
        {
            this._alumnos = new List<Alumno>();
        }
        
        public Curso(short anio, Divisiones division, Profesor profesor)
            :this()
        {
            this._anio = anio;
            this._division = division;
            this._profesor = profesor;
        }

        #endregion       
        #region SobreCargas

        public static explicit operator string (Curso c)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(c._profesor.ExponerDatos());
            sb.AppendLine(c.AnioDivision);
            sb.AppendLine("\nDatos de Cada Alumno:");

            foreach(Alumno temporal in c._alumnos)
            {
                sb.AppendLine(temporal.ExponerDatos());
            }

            return sb.ToString();
        }

        public static bool operator ==(Curso c, Alumno a)
        {
            bool retorno = false;
                    
           if(String.Compare(c.AnioDivision, a.AnioDivision) == 0)
           {
              retorno = true;
                   
           }
            

            return retorno;
        }
        public static bool operator !=(Curso c, Alumno a)
        {
            return !(c == a);
        }

        public static Curso operator +(Curso c, Alumno a)
        {
            if (c == a)
            {
                c._alumnos.Add(a);
            }

            return c;
        } 


        #endregion
    }
}
