﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloParcial
{
    public class Vehiculo
    {
        #region Atributos       

        protected string _patente;
        protected Byte _cantRuedas;
        protected Emarcas _marcas;

        #endregion
        #region Propiedades

        public string Patente
        {
            get
            {
                return this._patente;
            }

        }

        public Byte CantRuedas
        {
            get
            {
                return this._cantRuedas;
            }
            set
            {
                this._cantRuedas = value;
            }
        }

        public Emarcas Marca
        {
            get
            {
                return this._marcas;
            }
        }

        #endregion
        #region Metodos

        public Vehiculo(string patente, byte cantRuedas, Emarcas marca)
        {
            this._patente = patente;
            this.CantRuedas= cantRuedas;
            this._marcas = marca;
        }

        protected virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("La cantidad de ruedas es : {0}", this.CantRuedas);
            sb.AppendFormat("La patente es : {0}", this.Patente);
            sb.AppendFormat("La marca es : {0}", this.Marca);

            return sb.ToString();
        } 

        public override string ToString()
        {
            return this.Mostrar();
        }

        #endregion
        #region Sobrecargas

        public static bool operator ==(Vehiculo valorVehiculoUno, Vehiculo valorVehiculoDos)
        {
           return (valorVehiculoUno.Patente == valorVehiculoDos.Patente && valorVehiculoUno.Marca ==valorVehiculoDos.Marca);
        }

        public static bool operator !=(Vehiculo valorVehiculoUno, Vehiculo valorVehiculoDos)
        {
            return !(valorVehiculoUno == valorVehiculoDos);
        }
        #endregion
    }
}
