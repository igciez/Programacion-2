﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloParcial
{
    class Moto:Vehiculo
    {
        #region Atributo

        protected float _cilindrada;

        #endregion
        #region Constructores

        public Moto(string patente, byte cantRuedas, Emarcas marca,float cilindrada) : base(patente, cantRuedas, marca)
        {
            this._cilindrada = cilindrada;
        }
        public Moto(Emarcas marca, float cilindrada, string patente, byte cantRuedas) : this(patente, cantRuedas, marca, cilindrada)
        {

        }

        #endregion
        #region Metodos

        protected override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("La cilindrada de la Moto es: {0}", this._cilindrada);
            //sb.AppendLine(base.Mostrar());

            return sb.ToString();
        }

        public override string ToString()
        {
            return base.Mostrar();
        }

        #endregion
    }
}
