﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_16
{
    class Alumno
    {
        #region Campos

        private byte _nota1;
        private byte _nota2;
        private float _notaFinal;
        public string apellido="";
        public int legajo;
        public string nombre = "";
        #endregion
        #region Metodos
        public void CalcularFinal()
        {
            Random rnd = new Random();
            this._notaFinal = rnd.Next(4,10);

        }

        public void Estudiar(byte notaUno,byte notaDos)
        {
            this._nota1 = notaUno;
            this._nota2 = notaDos;
            
            if (notaUno >= 4 && notaDos >= 4)
            {
                CalcularFinal();
            }
            else
            {
                this._notaFinal = -1;
            }
        }

        public void Mostrar()
        {
            Console.WriteLine("Nombre del Alumno: {0}",this.nombre);
            Console.WriteLine("Apellido del Alumno: {0}",this.apellido);
            Console.WriteLine("Leagajo del Alumno: {0}",this.legajo);
            Console.WriteLine("Nota 1 del Alumno: {0}",this._nota1);
            Console.WriteLine("Nota 2 del Alumno: {0}",this._nota2);
            if(this._notaFinal != -1)
            {
                Console.WriteLine("Nota del Alumno: {0}",this._notaFinal);
            }
            else
            {
                Console.WriteLine("Alumno desaprobado");
            }
        }
        #endregion
    }
}
