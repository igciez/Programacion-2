﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class DirectorTecnico:Persona
    {
        #region Atributos

        private int _anosExperiencia;

        #endregion
        #region Propiedades

        public int AnosExperiencia
        {
            get
            {
                return this._anosExperiencia;
            }
            set
            {
                this._anosExperiencia = value;
            }
        }

        #endregion
        #region Constructores

        public DirectorTecnico (string nombre,string apellido, int edad, int dni, int anosExperiencia)
            : base(nombre, apellido, edad, dni)
        {
            this._anosExperiencia = anosExperiencia;
        }

        #endregion
        #region Metodos

        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.AppendFormat("\nAnos de experiencia:{0}", this._anosExperiencia);
            
            return sb.ToString();
        }

        public override bool ValidarAptitud()
        {
            bool retorno = false;

            if (base.Edad < 65 && this._anosExperiencia >= 2)
            {
                retorno = true;
            }

            return retorno;
        }

        #endregion
    }
}
