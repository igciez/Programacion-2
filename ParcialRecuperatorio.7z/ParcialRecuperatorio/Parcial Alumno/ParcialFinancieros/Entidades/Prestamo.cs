﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Prestamo
    {
        #region Atributos

        private float _monto;
        private DateTime _vencimiento;

        #endregion
        #region Propiedades

        public float Monto
        {
            get
            {
                return this._monto;
            }
        }
        public DateTime Vencimiento
        {
            get
            {
                return this._vencimiento;
            }
            set
            {
                if(value.Date > DateTime.Now)
                {
                    this._vencimiento = value;
                }
                else
                {
                    this._vencimiento = DateTime.Now;
                }
            }
        }
        #endregion
        #region Constructor

        public Prestamo(float monto,DateTime vencimiento)
        {
            this._vencimiento = vencimiento;
            this._monto = monto;
        }

        #endregion
        #region Metodos

        public static int OrdenarPorFecha(Prestamo p1 , Prestamo p2)
        {
            return DateTime.Compare(p1._vencimiento, p2._vencimiento);
        }

        public abstract void ExtenderPlazo(DateTime nuevoVencimiento);

        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("\nMonto:{0}", this._monto);
            sb.AppendFormat("\nVencimiento:{0}", this._vencimiento);

            return sb.ToString();
        }
        #endregion
    }
}
