﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio40
{
    public abstract class Llamada
    {
        #region Atributos

        protected float _duracion;
        protected string _nroDestino;
        protected string _nroOrigen;

        #endregion
        #region Propiedades

        public abstract float CostoLlamada { get; }
       
        public float Duracion
        {
            get
            {
                return this._duracion;
            }
        }

        public string NroDestino
        {
            get
            {
                return this._nroDestino;
            }
        }

        public string NroOrigen
        {
            get
            {
                return this._nroOrigen;
            }

        }

        #endregion
        #region Constructor

        public Llamada(float duracion,string nroDestino,string nroOrigen)
        {
            this._duracion = duracion;
            this._nroDestino = nroDestino;
            this._nroOrigen = nroOrigen;
        }

        #endregion
        #region Metodos

        protected virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("Duracion:{0}\n", this._duracion);
            sb.AppendFormat("Nro de Destino: {0}\n", this._nroDestino);
            sb.AppendFormat("Nro de Origen: {0}", this._nroOrigen);

            return sb.ToString();
        }

        public static int OrdenarPorDuracion (Llamada llamada1, Llamada llamada2)
        {
            int retorno = 0;

            if (llamada1._duracion > llamada2._duracion)
            {
                retorno = 1;
            }
            else if(llamada1._duracion < llamada2._duracion)
            {
                retorno = -1;
            }
            return retorno;
        }

        #endregion
        #region Sobrecargas

        public static bool operator ==(Llamada llamada1,Llamada llamada2)
        {
            return (llamada1.Equals(llamada2) && llamada1.NroDestino == llamada2.NroDestino && llamada1.NroOrigen == llamada2.NroOrigen);
        }

        public static bool operator !=(Llamada llamada1, Llamada llamada2)
        {
            return !(llamada1 == llamada2);
        }

        #endregion
    }
}
