﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Ejercicio40
{
    public class Provincial:Llamada
    {
        #region Enumerados

        public enum Franja
        {
            Franja_1,
            Franja_2,
            Franja_3
        }
        
        #endregion
        #region Atributos

        protected Franja _franjaHoraria;

        #endregion
        #region Propiedades

        public override float CostoLlamada
        {
            get
            {
                return this.CalcularCosto();
            }
        }

        #endregion
        #region Constructores

        public Provincial(Franja miFranja, Llamada llamada)
            : this(llamada.NroOrigen, miFranja, llamada.Duracion,llamada.NroDestino)
        {
        }

        public Provincial(string origen, Franja miFranja, float duracion,string destino)
            :base(duracion,destino,origen)
        {
            this._franjaHoraria = miFranja;
        }

        #endregion
        #region Metodos

        protected override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.AppendFormat("Costo de llamada:{0}\n", this.CalcularCosto());
            sb.AppendFormat("Franja Horaria: {0}", this._franjaHoraria);

            return sb.ToString();
        }

        private float CalcularCosto()
        {
            float retorno = 0;

            switch (this._franjaHoraria)
            {
                case Franja.Franja_1:
                    retorno = ((float)0.99) * base.Duracion;
                    break;
                case Franja.Franja_2:
                    retorno = ((float)1.25) * base.Duracion;
                    break;
                case Franja.Franja_3:
                    retorno = ((float)0.66) * base.Duracion;
                    break;
                default:
                    break;
            }

            return retorno;
        }

        public override bool Equals(object obj)
        {
            return obj is Provincial;
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        #endregion
    }
}
