﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Estacionamiento
    {
        #region Atributos

        private int _espacioDisponible;
        private string _nombre;
        private List<Vehiculo> _vehiculos;

        #endregion
        #region Constructores

        private Estacionamiento()
        {
            this._vehiculos = new List<Vehiculo>();
        }

        public Estacionamiento(string nombre, int espacioDisponible)
            :this()
        {
            this._nombre = nombre;
            this._espacioDisponible = espacioDisponible;
        }

        #endregion
        #region Metodos

        public static explicit operator string(Estacionamiento e)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("\nNombre:{0}\nEspacio Disponible:{1}", e._nombre, e._espacioDisponible);

            foreach(Vehiculo temporal in e._vehiculos)
            {
                sb.AppendLine(temporal.ImprimirTicket());
            }

            return sb.ToString();
        }

        public static bool operator ==(Estacionamiento estacionamiento,Vehiculo vehiculo)
        {
            bool retorno = false;

            foreach(Vehiculo temporal in estacionamiento._vehiculos)
            {
                if(temporal == vehiculo)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }

        public static bool operator !=(Estacionamiento estacionamiento, Vehiculo vehiculo)
        {
            return !(estacionamiento == vehiculo);
        }

        public static Estacionamiento operator +(Estacionamiento estacionamiento, Vehiculo vehiculo)
        {
            if( estacionamiento != vehiculo && !Object.Equals(vehiculo.Patente,null) && estacionamiento._espacioDisponible > 0)
            {
                estacionamiento._vehiculos.Add(vehiculo);
                estacionamiento._espacioDisponible--;
            }
            

            return estacionamiento;
        }

        public static string operator -(Estacionamiento estacionamiento, Vehiculo vehiculo)
        {
            if (estacionamiento == vehiculo)
            {
                estacionamiento._vehiculos.Remove(vehiculo);
                estacionamiento._espacioDisponible++;
                return vehiculo.ImprimirTicket();
            }
            else
            {
                return "\nEl vehiculo no es parte del estacionamiento.";
            }
        }


        #endregion
    }
}
