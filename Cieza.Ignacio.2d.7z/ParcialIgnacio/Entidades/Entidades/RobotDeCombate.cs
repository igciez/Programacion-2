﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class RobotDeCombate : Robot
    {
        #region Atributos

        private bool _lucho;
        private int _caballosDeFuerza;

        #endregion
        #region Propiedades

        public int CaballoDeFuerza
        {
            get
            {
                return this._caballosDeFuerza;
            }
        }

        public bool Lucho
        {
            get
            {
                return this._lucho;
            }
        }


        #endregion
        #region Constructores

        public RobotDeCombate()
        {
            this._lucho = false;
        }

        public RobotDeCombate(int energia, string origen):this(energia,origen,10)
        {
            this._lucho = false;
        }

        public RobotDeCombate(int energia, string origen, int caballosDeFuerza):base(energia,origen)
        {
            this._caballosDeFuerza = caballosDeFuerza;
        }

        #endregion
        #region Metodos
        /// <summary>
        /// En base a la enrgia retornar un mensaje con el estado del Robot
        /// </summary>
        /// <returns>string</returns>
        public override string ServirHumanidad()
        {
            if (base.Energia > 0)
            {
                base._energia--;
                return String.Format("\nRobot de Combate {0} - Disparando Misiles...", base.Codigo);
            }
            else
            {
                return String.Format("\nRobot de Combate {0} - Sin Energia...", base.Codigo);
            }
        
        }

        #endregion
    }
}
