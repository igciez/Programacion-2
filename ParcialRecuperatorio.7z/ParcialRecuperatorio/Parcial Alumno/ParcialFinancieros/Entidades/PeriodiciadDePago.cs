﻿public enum PeriodicidadDePago
{
    Mensual, 
    Bimestral,
    Trimestra
}