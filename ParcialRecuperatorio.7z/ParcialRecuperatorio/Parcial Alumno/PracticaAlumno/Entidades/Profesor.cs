﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
   public  class Profesor:Persona
    {
        #region Atributos

        private DateTime _fechaIngreso;

        #endregion
        #region Propiedades

        public int Antiguedad
        {
            get
            {               
                return (this._fechaIngreso.Day - DateTime.Now.Day);
            }
        }
        #endregion
        #region Constructores

        public Profesor(string nombre, string apellido, string documento)
            :base(nombre,apellido,documento)
        {
        }

        public Profesor(string nombre, string apellido, string documento, DateTime fechaIngreso)
            :this(nombre,apellido,documento)
        {
            this._fechaIngreso = fechaIngreso;
        }

        #endregion
        #region Metodos

        public override bool ValidarDocumentacion(string doc)
        {
            bool retorno = false;

            if (doc.Length == 8)
            {
                retorno = true;
            }

            return retorno;
        }

        public override string ExponerDatos()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.ExponerDatos());
            sb.AppendFormat("\nFecha de ingreso:{0}", this._fechaIngreso);

            return sb.ToString();
        }

        #endregion
    }
}
