﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_11
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int i;
            int maximo = 0;
            int minimo = 0;
            int max = 100;
            int min = -100;
            int contador = 10;
            float promedio;
            float acumulador = 0;


            Console.Title = "Ejercicio Nro 11";


            for (i = 0; i < contador; i++)
            {
                Console.Write("Ingrese el {0} numero :", i + 1);
                numero = int.Parse(Console.ReadLine());


                if (Validacion.Validar(numero, min, max))
                {
                    acumulador += numero;

                    if (i == 0)
                    {
                        maximo = numero;
                        minimo = numero;
                    }

                    else if (numero > maximo)
                    {
                        maximo = numero;
                    }
                    else if (numero < minimo)
                    {
                        minimo = numero;
                    }
                }
                else
                {
                    Console.WriteLine("Error, vuelva a ingresar el numero.");               
                    i--;
                }
            }
            promedio = acumulador / contador; //el acumulador se declara float porque si es int con int, no calcula decimal. entonces es necesario castear. ej. (float)5; para que al menos alguno sea decimal.

            Console.WriteLine("El maximo es: {0}", maximo);
            Console.WriteLine("El minimo es: {0}", minimo);
            Console.WriteLine("El promedio es: {0:0.00}", promedio);

            Console.Read();

        }
    }
    
}
