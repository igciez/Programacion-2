﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Jugador:Persona
    {
        #region Enumerados

        public enum Posicion
        {
            Arquero,
            Defensor,
            Central,
            Delantero
        }

        #endregion
        #region Atributos

        private float _altura;
        private float _peso;
        private Posicion _posicion;

        #endregion
        #region Propiedades

        public float Altura
        {
            get
            {
                return this._altura;
            }
        }

        public float Peso
        {
            get
            {
                return this._peso;
            }
        }

        public Posicion PropPosicion
        {
            get
            {
                return this._posicion;
            }
        }

        #endregion
        #region Constructores

        public Jugador(string nombre, string apellido,int edad, int dni,float peso,float altura,Posicion posicion)
            : base(nombre, apellido, edad, dni)
        {
            this._altura = altura;
            this._peso = peso;
            this._posicion = posicion;
        }

        #endregion
        #region Metodos

        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(base.Mostrar());
            sb.AppendFormat("\nAltura:{0}", this._altura);
            sb.AppendFormat("\nPeso:{0}", this._peso);
            sb.AppendFormat("\nPosicion:{0}", this._posicion);

            return sb.ToString();
        }

        public override bool ValidarAptitud()
        {
            bool retorno = false;

            if(base.Edad < 40 && this.ValidarEstadoFisico())
            {
                retorno = true;
            }

            return retorno;
        }

        public bool ValidarEstadoFisico()
        {
            bool retorno = false;
            float imc = 0;

            imc = this._peso / (this._altura * this._altura);

            if(imc >=18.5 && imc <= 25)
            {
                retorno = true;
            }

            return retorno;           
        }
        #endregion
    }
}
