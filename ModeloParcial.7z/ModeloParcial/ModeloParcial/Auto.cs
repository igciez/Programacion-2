﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModeloParcial
{
    class Auto:Vehiculo
    {
        #region Atributo

        protected int _cantidadAsientos;

        #endregion
        #region Constructores

        public Auto(string patente, byte cantRuedas, Emarcas marca, int cantidadAsientos) : base(patente, cantRuedas, marca)
        {
            this._cantidadAsientos = cantidadAsientos;
        }
        public Auto(string patente, Emarcas marca, int cantidadAsientos) : this(patente, 4, marca, cantidadAsientos)
        {

        }

        #endregion
        #region Metodos

        protected override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("La cantidad de asientos del Auto es: {0}", this._cantidadAsientos);
            //b.AppendLine(base.Mostrar());

            return sb.ToString();
        }

        public override string ToString()
        {
            return base.Mostrar();
        }

        #endregion
    }
}
