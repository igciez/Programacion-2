﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio40
{
    public class Centralita
    {
        #region Atributos

        protected List<Llamada> _listaDeLlamadas;
        protected string _razonSocial;

        #endregion
        #region Propiedades

        public float GananciasPorLocal
        {
            get
            {
                return CalcularGanancia(TipoLlamada.Local);
            }
        }
        public float GananciasPorProvincia
        {
            get
            {
                return CalcularGanancia(TipoLlamada.Provincial);
            }
        }
        public float GananciasPorTotal
        {
            get
            {
                return CalcularGanancia(TipoLlamada.Todas);
            }
        }
        public List<Llamada> Llamadas
        {
            get
            {
                return this._listaDeLlamadas;
            }
        }

        #endregion
        #region Constructores

        public Centralita()
        {
            this._listaDeLlamadas = new List<Llamada>();
        }

        public Centralita(string nombreEmpresa):this()
        {
            this._razonSocial = nombreEmpresa;
        }

        #endregion
        #region Metodos

        protected string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Razón Social: {0}\nGanancia Total: {1}\nGanancia por Locales: {2}\nGanancia por Provinciales: {3}\n",
                this._razonSocial, this.GananciasPorTotal, this.GananciasPorLocal, this.GananciasPorProvincia);
            foreach (Llamada llamada in this._listaDeLlamadas)
            {
                switch (llamada.GetType().ToString())
                {
                    case ("CentralitaHerencia.Local"):
                        sb.AppendLine(((Local)llamada).ToString());//se referencia por cast de llamada a local
                        break;
                    case ("CentralitaHerencia.Provincial"):
                        sb.AppendLine(((Provincial)llamada).ToString());
                        break;
                }
            }
            return sb.ToString();
        }

        private float CalcularGanancia(TipoLlamada tipo)
        {
            float retorno = 0;

            switch (tipo)
            {
                case TipoLlamada.Local:
                    foreach(Llamada llamada in this._listaDeLlamadas)
                    {
                        if(llamada is Local)
                        {
                            retorno += ((Local)llamada).CostoLlamada;
                        }
                    }                    
                    break;
                case TipoLlamada.Provincial:
                    foreach (Llamada llamada in this._listaDeLlamadas)
                    {
                        if (llamada is Provincial)
                        {
                            retorno += ((Provincial)llamada).CostoLlamada;
                        }
                    }
                    break;
                case TipoLlamada.Todas:
                    foreach (Llamada llamada in this._listaDeLlamadas)
                    {
                        if (llamada is Local)
                        {
                            retorno += ((Local)llamada).CostoLlamada;
                        }
                        else if (llamada is Provincial)
                        {
                            retorno += ((Provincial)llamada).CostoLlamada;
                        }
                    }
                    break;
                default:
                    break;
            }
            return retorno;
        }

        public void OrdenarLlamadas()
        {
            this._listaDeLlamadas.Sort(Llamada.OrdenarPorDuracion);
            //se hace un ordenmiento del arraylist, 
            //en base a la posicion de las llamadas que tenga, se ordenara por duracion.
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        private void AgregarLlamada(Llamada nuevaLlamada)
        {
            this._listaDeLlamadas.Add(nuevaLlamada);
        }

        #endregion
        #region Sobrecargas

        public static bool operator ==(Centralita c,Llamada l)
        {
            bool retorno = false;

            foreach (Llamada llamada in c._listaDeLlamadas)
            {
                if (llamada == l)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }
        public static bool operator !=(Centralita c, Llamada l)
        {
            return !(c == l);
        }

        public static Centralita operator +(Centralita c,Llamada nuevaLlamada)
        {
            if(c != nuevaLlamada)
            {
                c.AgregarLlamada(nuevaLlamada);
            }

            return c;
        }

        #endregion
    }
}
