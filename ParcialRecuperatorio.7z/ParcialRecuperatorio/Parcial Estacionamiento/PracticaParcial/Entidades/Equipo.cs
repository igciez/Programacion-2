﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Equipo
    {
        #region Atributos

        private const int _cantidadMaximaJugadores=6;
        private DirectorTecnico _directorTecnico;
        private List<Jugador> _jugadores;
        private string _nombre;

        #endregion
        #region Propiedades

        public DirectorTecnico PropDirectorTecnico
        {
            set
            {
                if (value.ValidarAptitud())
                {
                    this._directorTecnico = value;
                }
                else
                {
                    this._directorTecnico = null;
                }
            }
        }

        public string Nombre
        {
            get
            {
                return this._nombre;
            }
        }

        #endregion
        #region Constructores

        private Equipo()
        {
            this._jugadores = new List<Jugador>();
        }

        public Equipo(string nombre):this()
        {
            this._nombre = nombre;
        }

        #endregion
        #region Metodos

        public static bool ValidarEquipo(Equipo e)
        {
            bool retorno = false;
            int contArquero = 0;
            int contDefensor = 0;
            int contCentral = 0;
            int contDelantero = 0;

            foreach(Jugador j in e._jugadores)
            {
                switch (j.PropPosicion)
                {
                    case Jugador.Posicion.Arquero:
                        contArquero++;
                        break;
                    case Jugador.Posicion.Defensor:
                        contDefensor++;
                        break;
                    case Jugador.Posicion.Central:
                        contCentral++;
                        break;
                    case Jugador.Posicion.Delantero:
                        contDelantero++;
                        break;
                    default:
                        break;
                }
            }

            if(!Object.Equals(e._directorTecnico,null) && contArquero ==1&& contCentral >=1 && contDefensor >=1 && contDelantero >=1 && e._jugadores.Count ==Equipo._cantidadMaximaJugadores)
            {
                retorno = true;
            }

            return retorno;
        }

        #endregion
        #region SobreCargas

        public static explicit operator string(Equipo e)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("\nNombre del Equipo:{0}", e._nombre);
            if (!Object.Equals(e._directorTecnico, null))
            {
                sb.AppendFormat("\nNombre del Director Tecnico:{0}", e._directorTecnico.Nombre);
            }
            else
            {
                sb.AppendLine("\nSin DT asignado");
            }
            sb.AppendLine("\nNombre de Jugadores:");

            if (!Object.Equals(e._jugadores, null))
            {
                foreach (Jugador jugador in e._jugadores)
                {
                    sb.AppendLine(jugador.Mostrar());
                }
            }
            else
            {
                sb.AppendLine("No se han cargado Jugadores");
            }

            return sb.ToString();            
        }

        public static bool operator==(Equipo e, Jugador j)
        {
            bool retorno = false;

            if (!Object.Equals(e._jugadores, null))
            {
                foreach (Jugador jugador in e._jugadores)
                {
                    if(jugador == j)
                    {
                        retorno = true;
                        break;
                    }
                }
            }

            return retorno;
        }

        public static bool operator !=(Equipo e, Jugador j)
        {
            return !(e == j);
        }

        public static Equipo operator +(Equipo e, Jugador j)
        {
            if(e!=j && Equipo._cantidadMaximaJugadores<=6 && j.ValidarAptitud())
            {
                e._jugadores.Add(j);
            }

            return e;
        }

        #endregion
    }
}
