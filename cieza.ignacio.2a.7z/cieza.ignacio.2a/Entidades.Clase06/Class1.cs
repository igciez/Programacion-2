﻿using System;

namespace Entidades.Clase06
{
    public class Class1
    {

    }
}
