﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_04
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero = 0;
            int i;
            int j;
            int acumulador = 0;
            int acumuladorDos = 4;
            

            Console.Write("Ingrese un numero: ");
            numero = int.Parse(Console.ReadLine());

            for (i = 1; i <= numero; i++)
            {
                acumulador = 0;
                for (j = 1; j < i; j++)
                {
                    if (i % j == 0)
                    {
                        acumulador += j;
                        
                    }
                                                     
                }
                if (acumulador == i && acumuladorDos > 0)
                {
                    Console.WriteLine("El numero {0}, contiene al numero Perfecto {1}.",numero, i);
                    acumuladorDos--;
                }
            }

            /*if(acumulador !)
            {
                Console.WriteLine("El numero {0}, no es un numero Perfecto.", numero);
            }*/

            Console.Read();
        }
    }
}
    

