﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Automovil: Vehiculo
    {
        #region Atributos

        private ConsoleColor _color;
        private static int _valorHora;

        #endregion
        #region Constructores

        static Automovil()
        {
            Automovil._valorHora = 50;
        }

        public Automovil(string patente,ConsoleColor color)
            :base(patente)
        {
            this._color = color;
        }

        public Automovil(string patente, ConsoleColor color,int valorHora)
            :this(patente,color)
        {
            Automovil._valorHora = valorHora;
        }

        #endregion
        #region Metodos

        public override string ConsultarDatos()
        {
            return string.Format("\nColor: {0}\nValor Hora: {1}", this._color, Automovil._valorHora);
        }

        public override string ImprimirTicket()
        {
            StringBuilder sb = new StringBuilder();
            int costoEstadia = 0;

            costoEstadia = (int)((DateTime.Now - base._ingreso).TotalHours) * (Automovil._valorHora);
            

            sb.AppendLine(base.ImprimirTicket());
            sb.AppendFormat("La hora de Egreso es: {0}", DateTime.Now);
            sb.AppendFormat("\nEl costo de la estadia es {0}", costoEstadia);
            

            return sb.ToString();
        }

        public override bool Equals(object obj)
        {
            return (obj is Automovil);
        }

        #endregion
    }
}
