﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_12
{
    class Program
    {
        static void Main(string[] args)
        {
            int acumuladorSuma = 0;            
            char salir = 'N';

            do
            {
                Console.Write("Ingrese un numero entero a Sumar: ");
                if(int.TryParse(Console.ReadLine(),out int suma))
                {
                    acumuladorSuma += suma;
                }
                else
                {
                    Console.WriteLine("\nError, ingrese un numero entero");
                }
                Console.Write("\nDesea continuar?");
                salir=char.Parse(Console.ReadLine());

               // Console.Read();

            } while (ValidarRespuesta.ValidaS_N(salir));

            Console.WriteLine("La suma de los numero ingresados es: {0}",acumuladorSuma);
            Console.Read();

        }
    }
}
