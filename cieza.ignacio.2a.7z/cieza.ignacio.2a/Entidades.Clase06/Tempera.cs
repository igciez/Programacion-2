﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Clase06
{
    class Tempera
    {
        private sbyte _cantidad;
        private ConsoleColor _color;
        private string _marca;

        #region Constructor
        public Tempera(sbyte valorCantidad, ConsoleColor valorColor, string valorMarca)
        {
            this._cantidad = valorCantidad;
            this._color = valorColor;
            this._marca = valorMarca;
        }
        #endregion
        #region Metodos
        public static string Mostrar(Tempera valorTempera)
        {
            //        if((object)valorTinta != null)
            if (!Object.Equals(valorTempera, null))
                return valorTempera.Mostrar();
            return "-Sin Tempera-";
        }

        private string Mostrar()
        {
            return this._cantidad + "--" + this._color + "--" + this._marca;
        }
        #endregion
        #region Sobrecarga

        public static implicit operator string(Tempera valorTempera)
        {
            return valorTempera.Mostrar();
        }

        public static explicit operator sbyte(Tempera valorTempera)
        {
            return valorTempera._cantidad;
        }

        public static bool operator ==(Tempera valorColor, Tempera valorMarca)
        {
            bool var = false;
            if (valorColor._color == valorMarca._color && valorColor._marca == valorMarca._marca)
                var = true;
            return var; //puede ir (valorColor._color == valorMarca._color && valorColor._marca == valorMarca._marca) directamente.
        }

        public static bool operator !=(Tempera valorColor, Tempera valorMarca)
        {
            return !(valorColor == valorMarca);
        }

        public static Tempera operator +(Tempera valorTempera, sbyte valorCantidad)//completar 
        {


            valorTempera._cantidad += valorCantidad;
            
            return valorTempera;
        }

        public static Tempera operator + (Tempera valorTemperaUno, Tempera valorTemperaDos) //completar 
        {

            if (valorTemperaUno == valorTemperaDos)
            {
                return valorTemperaDos;  
            }

        }



        #endregion


    }
}
