using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  class Cosa
  {
    public string cadena;
    public double numero;
    public DateTime fecha;

    public Cosa()
    {
      this.cadena = "Sin Valor";
      this.numero = 1.9;
      this.fecha = DateTime.Now;
    }

    public Cosa(string c):this()
    {
      this.cadena = c;
      //this.numero = 1.9;
      //this.fecha = DateTime.Now;
    }

    public void EstablecerValor(string algo)
    {
      this.cadena = algo;
    }

    public void EstablecerValor(Double algo)
    {
      this.numero = algo;
    }

    public static string Mostrar(Cosa algo)
    {    
      return algo.Mostrar();
    }
    private string Mostrar()
    { 
      return this.cadena + "// " + this.numero.ToString() + "// "+ this.fecha.ToLongTimeString(); 
    }
  }
}
