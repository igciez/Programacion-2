using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clase_6
{
  public partial class frmTinta : Form
  {
    public frmTinta()
    {
      InitializeComponent();

      foreach (ConsoleColor color in Enum.GetValues(typeof(ConsoleColor)))
      {
        this.cboColor.Items.Add(color);
      }

      foreach (EtipoTinta tipo in Enum.GetValues(typeof(EtipoTinta)))
      {
        this.cboTipo.Items.Add(tipo);
      }
    }

    private void label1_Click(object sender, EventArgs e)
    {

    }

    private void label2_Click(object sender, EventArgs e)
    {

    }

    private void frmTinta_Load(object sender, EventArgs e)
    {

    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
      

    }
  }
}
