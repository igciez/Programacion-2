using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_05
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.Title = "Pluma";
      Tinta t1 = new Tinta(ConsoleColor.Blue, EtipoTinta.China);
      Pluma pluma1 = new Pluma("aa", 9, t1);

      Pluma p = new Pluma();


      p += t1;
      Console.WriteLine(p);

      
      pluma1 += t1;

      Console.WriteLine(pluma1);

      Console.ReadLine();
    }
  }
}
