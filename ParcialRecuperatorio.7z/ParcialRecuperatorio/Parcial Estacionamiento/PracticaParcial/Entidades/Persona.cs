﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Persona
    {
        #region Atributos

        private string _apellido;
        private int _dni;
        private int _edad;
        private string _nombre;


        #endregion
        #region Propiedades

        public string Apellido
        {
            get
            {
                return this._apellido;
            }
        }

        public int Dni
        {
            get
            {
                return this._dni;
            }
        }

        public int Edad
        {
            get
            {
                return this._edad;
            }
        }

        public string Nombre
        {
            get
            {
                return this._nombre;
            }
        }

        #endregion
        #region Constructores

        public Persona(string nombre,string apellido, int edad, int dni)
        {
            this._nombre = nombre;
            this._apellido = apellido;
            this._edad = edad;
            this._dni = dni;
        } 

        #endregion
        #region Metodos

        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendFormat("\nNombre:{0}", this._nombre);
            sb.AppendFormat("\nApellido:{0}", this._apellido);
            sb.AppendFormat("\nEdad:{0}", this._edad);
            sb.AppendFormat("\nDni: {0}", this._dni);

            return sb.ToString();
        }

        public abstract bool ValidarAptitud();

        #endregion
    }
}
