﻿public enum TipoDePrestamo
{
    Pesos,
    Dolares,
    Todos
}