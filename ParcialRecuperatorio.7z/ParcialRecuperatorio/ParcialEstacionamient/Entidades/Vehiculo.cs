﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Vehiculo
    {
        #region Atributos

        protected DateTime _ingreso;
        private string _patente;

        #endregion
        #region Propiedades

        public string Patente
        {
            get
            {
                return this._patente;
            }
            set
            {
                if(value.Length == 6)
                {
                    this._patente = value;
                }
            }
        }

        #endregion
        #region Constructor

        public Vehiculo(string patente)
        {
            this.Patente = patente;
            this._ingreso = DateTime.Now.AddHours(-3);
        }

        #endregion
        #region Metodos

        public abstract string ConsultarDatos();

        public override string ToString()
        {
            return String.Format("\nPatente {0}", this._patente);
        }

        public virtual string ImprimirTicket()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(this.ToString());
            sb.AppendFormat("\nFecha y Hora de ingreso {0}", this._ingreso);

            return sb.ToString();
        }

        #endregion
        #region SobreCargas

        public static bool operator ==(Vehiculo v1, Vehiculo v2)
        {
            return (v1.Equals(v2) && v1._patente == v2._patente);
        }

        public static bool operator !=(Vehiculo v1, Vehiculo v2)
        {
            return !(v1 == v2);
        }

        #endregion
    }
}
