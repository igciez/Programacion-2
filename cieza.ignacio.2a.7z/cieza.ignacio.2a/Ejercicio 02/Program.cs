using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;

namespace Ejercicio_02
{
    class Program
    {
        static void Main(string[] args)
        {
            Sello.mensaje = /*"";*/"Hola";

            Console.Write(Sello.Imprimir());
            

            //Sello.Borrar();
            Sello.color = ConsoleColor.Blue;
            Sello.ImprimirEnColor();
            Console.Write(Sello.Imprimir());

            //Console.WriteLine(Sello.Imprimir());

            Console.Read();
        }
    }
}
