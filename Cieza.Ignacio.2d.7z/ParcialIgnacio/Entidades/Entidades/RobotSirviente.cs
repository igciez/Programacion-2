﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class RobotSirviente:Robot
    {
        #region Constructores

        public RobotSirviente():base()
        {

        }
        public RobotSirviente(int energia,string origen):base(energia,origen)
        {

        }

        #endregion
        #region Metodos
        /// <summary>
        /// Carga el valor energia en caso de que el robot tenga 0 energia
        /// </summary>
        /// <param name="energia">valor a cargar en el campor energia</param>
        /// <returns>bool</returns>
        public override bool CargarEnergia(int energia)
        {
            bool retorno = false;

            if (this._energia == 0)
            {
                this._energia = energia;
                retorno = true;
            }

            return retorno;
        }
        /// <summary>
        /// Descuenta en una unidad el atributo energia del robot en caso de que tenga energia
        /// </summary>
        /// <returns>string, el resultado de la energia contenida</returns>
        public override string ServirHumanidad()
        {
            if (base.Energia > 0)
            {
                base._energia--;
                return String.Format("\nHaciendo masajes.");
            }
            else
            {
                return String.Format("\nSin Energia");
            }

        }

        #endregion

    }
}
