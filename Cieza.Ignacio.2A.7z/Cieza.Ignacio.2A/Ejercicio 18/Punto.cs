﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_18
{
    class Punto
    {
        #region Atributos
        private static int x;
        private static int y;
        #endregion

        #region Metodos

        public int GetX()
        {
            return x;
        }
        public int GetY()
        {
            return y;
        }
        #endregion
    }
}
